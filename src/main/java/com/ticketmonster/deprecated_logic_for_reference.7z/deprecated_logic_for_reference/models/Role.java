package com.ticketmonster.deprecated_logic_for_reference.models;

public enum Role{
    USER,
    ADMIN
}
